<?php

namespace App\Think\Providers;

use App\Module\ServiceProvider;

class ThinkServiceProvider extends ServiceProvider
{
    public $name = "think";
    public $Name = "Think";
}
