<?php

namespace App\Think\Providers;

use Illuminate\Support\Facades\Route;
use App\Module\RouteServiceProvider as ServiceProvider;

class RouteServiceProvider extends ServiceProvider
{
    public $name = "think";
    public $Name = "Think";
}
