<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/12/1
 * Time: 11:39
 */

namespace app\common\model;

use think\Model;

class WxTplMsg extends Model
{

}