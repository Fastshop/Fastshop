<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/7/31
 * Time: 11:59
 */

namespace app\common\model;


use think\Model;

class OauthUsers extends Model
{

}